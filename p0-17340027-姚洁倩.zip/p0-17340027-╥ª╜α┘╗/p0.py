import math
x = input('Please enter a number x')
y = input('Please enter a number y')
x = int(x)
y = int(y)
power = x**y
print('x**y =',power,'\n')
log = math.log(x,2)
print('log(x) =',log,'\n')
input("skfj")